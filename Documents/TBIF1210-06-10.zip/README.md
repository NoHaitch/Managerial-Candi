TUGAS BESAR DASAR PEMOGRAMAN ITB 2023

Program Manajerial Candi

Kelas 06
Kelompok 10
Nama anggota: 
  1. (16522024) Bagaswara
  2. (19622024) Serenada Cinta Sunindyo
  3. (19622150) Dedy Hofmanindo Saragih
  4. (19622078) Raden Francisco Trianto Bratadiningrat 